---
name: "ui-designer"
description: "Provides UI/UX design guidance, color schemes, layout suggestions, and styling best practices. Invoke when user asks for UI design help, color recommendations, layout improvements, or CSS/styling assistance."
---

# UI 设计师技能

这是一个专业的 UI 设计助手技能，帮助您创建美观、易用的用户界面。

## 主要功能

### 1. 界面布局设计
- 提供响应式布局建议
- 组件排列和视觉层次结构设计
- 间距、对齐和网格系统指导
- 移动端和桌面端适配方案

### 2. 配色方案设计
- 品牌色彩搭配建议
- 主色、辅助色、强调色选择
- 无障碍色彩对比度检查
- 暗色/亮色主题配色方案

### 3. 样式代码编写
- CSS/SCSS 最佳实践
- Tailwind CSS 类名建议
- CSS-in-JS 方案指导
- 动画和过渡效果实现

### 4. 设计审查与优化
- 现有界面改进建议
- 用户体验优化方案
- 设计一致性检查
- 可访问性改进建议

## 使用场景

当您需要以下帮助时，可以请求此技能：

1. **设计新界面**：从零开始设计页面布局和视觉风格
2. **配色咨询**：选择合适的颜色方案和色彩搭配
3. **样式编写**：获取 CSS/样式代码建议和最佳实践
4. **设计评审**：对现有设计进行审查并提供改进建议
5. **响应式设计**：解决多设备适配问题
6. **组件设计**：设计可复用的 UI 组件

## 设计原则

此技能遵循以下设计原则：

- **简洁性**：保持界面简洁，避免过度设计
- **一致性**：确保设计语言和交互模式一致
- **可访问性**：关注所有用户的使用体验
- **响应式**：适配不同屏幕尺寸和设备
- **性能优先**：在保证美观的同时考虑性能影响

## 技术栈支持

- CSS3 / SCSS / Less
- Tailwind CSS
- CSS-in-JS (styled-components, emotion)
- Material-UI / Ant Design / Chakra UI
- Figma 设计转代码

## 示例用法

```
用户：帮我设计一个登录页面的布局
用户：这个按钮的颜色搭配不太好看，有什么建议？
用户：如何用 Tailwind CSS 实现一个响应式卡片布局？
用户：审查一下这个组件的设计，有什么改进建议？
```
