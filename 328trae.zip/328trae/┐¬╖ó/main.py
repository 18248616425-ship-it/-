from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os
import json
from datetime import datetime

app = FastAPI()

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 静态文件服务
app.mount("/view", StaticFiles(directory="view"), name="view")

# 临时存储
files = []
conversations = []

@app.get("/")
async def root():
    return {"message": "智能AI备课系统后端服务"}

# 知识库管理API
@app.post("/api/documents/upload")
async def upload_document(
    file: UploadFile = File(...),
    category: str = Form(None),
    tags: str = Form(None)
):
    # 保存文件
    file_path = f"files/{file.filename}"
    os.makedirs("files", exist_ok=True)
    with open(file_path, "wb") as f:
        f.write(await file.read())
    
    # 解析标签
    tags_list = []
    if tags:
        try:
            tags_list = json.loads(tags)
        except:
            tags_list = [tags]
    
    # 创建文件记录
    file_id = len(files) + 1
    file_record = {
        "id": file_id,
        "title": file.filename,
        "file_path": file_path,
        "file_type": file.filename.split(".")[-1],
        "file_size": os.path.getsize(file_path),
        "category": category or "其他",
        "tags": tags_list,
        "status": "ready",
        "created_at": datetime.now().isoformat()
    }
    files.append(file_record)
    
    return {
        "code": 200,
        "message": "上传成功",
        "data": {
            "document_id": file_id,
            "status": "processing"
        }
    }

@app.get("/api/documents")
async def get_documents(
    page: int = 1,
    size: int = 20,
    category: str = None,
    keyword: str = None
):
    # 过滤文件
    filtered_files = files
    if category:
        filtered_files = [f for f in filtered_files if f["category"] == category]
    if keyword:
        filtered_files = [f for f in filtered_files if keyword in f["title"]]
    
    # 分页
    start = (page - 1) * size
    end = start + size
    paginated_files = filtered_files[start:end]
    
    return {
        "code": 200,
        "data": {
            "total": len(filtered_files),
            "items": paginated_files
        }
    }

@app.delete("/api/documents/{document_id}")
async def delete_document(document_id: int):
    global files
    file_index = next((i for i, f in enumerate(files) if f["id"] == document_id), None)
    if file_index is None:
        raise HTTPException(status_code=404, detail="文件不存在")
    
    # 删除文件
    file_path = files[file_index]["file_path"]
    if os.path.exists(file_path):
        os.remove(file_path)
    
    # 从列表中移除
    files.pop(file_index)
    
    return {
        "code": 200,
        "message": "删除成功"
    }

# AI备课助手API
@app.post("/api/conversations")
async def create_conversation(
    document_id: int = Form(...),
    type: str = Form("preparation")
):
    # 检查文件是否存在
    file = next((f for f in files if f["id"] == document_id), None)
    if not file:
        raise HTTPException(status_code=404, detail="文件不存在")
    
    # 创建对话
    conversation_id = len(conversations) + 1
    conversation = {
        "id": conversation_id,
        "document_id": document_id,
        "type": type,
        "messages": [],
        "created_at": datetime.now().isoformat()
    }
    conversations.append(conversation)
    
    return {
        "code": 200,
        "data": {
            "conversation_id": conversation_id
        }
    }

@app.post("/api/conversations/{conversation_id}/messages")
async def send_message(
    conversation_id: int,
    content: str = Form(...)
):
    # 检查对话是否存在
    conversation = next((c for c in conversations if c["id"] == conversation_id), None)
    if not conversation:
        raise HTTPException(status_code=404, detail="对话不存在")
    
    # 添加用户消息
    user_message = {
        "id": len(conversation["messages"]) + 1,
        "role": "user",
        "content": content,
        "created_at": datetime.now().isoformat()
    }
    conversation["messages"].append(user_message)
    
    # 生成AI回复（模拟）
    ai_message = {
        "id": len(conversation["messages"]) + 1,
        "role": "assistant",
        "content": f"这是对问题 '{content}' 的回答",
        "sources": [{
            "document_id": conversation["document_id"],
            "document_title": next((f["title"] for f in files if f["id"] == conversation["document_id"]), "未知文档"),
            "chunk_id": 1,
            "content": "相关内容片段"
        }],
        "created_at": datetime.now().isoformat()
    }
    conversation["messages"].append(ai_message)
    
    return {
        "code": 200,
        "data": {
            "message_id": ai_message["id"],
            "role": ai_message["role"],
            "content": ai_message["content"],
            "sources": ai_message["sources"],
            "created_at": ai_message["created_at"]
        }
    }

# 授课AI助手API
@app.post("/api/teaching/quick-ask")
async def quick_ask(
    question: str = Form(...),
    ppt_content: str = Form(None),
    enable_web_search: bool = Form(True)
):
    # 模拟双轨回答
    knowledge_answer = {
        "content": f"根据知识库，关于 '{question}' 的回答",
        "sources": [{
            "document_id": 1,
            "document_title": "小学数学教案.docx",
            "chunk_id": 1,
            "content": "相关内容片段"
        }]
    }
    
    web_answer = {
        "content": f"根据网络搜索，关于 '{question}' 的回答",
        "sources": [{
            "title": "相关网页",
            "url": "https://example.com",
            "snippet": "网页内容片段"
        }]
    }
    
    return {
        "code": 200,
        "data": {
            "knowledge_answer": knowledge_answer,
            "web_answer": web_answer
        }
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
