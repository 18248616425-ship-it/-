# 智能AI备课系统 - 架构设计文档

## 一、系统概述

### 1.1 项目背景
为教师提供智能化的备课和授课辅助工具，通过AI技术提升教学效率和质量。

### 1.2 核心功能
- **知识库管理**：支持上传和管理教案、课标、教材等备课资料
- **AI备课助手**：基于知识库的智能问答，辅助教师备课
- **授课AI助手**：PPT授课时的实时AI辅助，解答学生问题

### 1.3 技术选型
- **应用类型**：Web应用
- **用户规模**：单用户/个人使用
- **AI模型**：灵活配置（支持OpenAI、国内大模型、本地模型）
- **部署方式**：本地部署或轻量级云部署

---

## 二、系统架构设计

### 2.1 整体架构图

```
┌─────────────────────────────────────────────────────────────┐
│                        前端层 (Frontend)                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │  知识库管理   │  │  备课助手    │  │  授课助手    │       │
│  │   模块       │  │    模块      │  │  (悬浮窗)    │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└─────────────────────────────────────────────────────────────┘
                            ↕ HTTP/WebSocket
┌─────────────────────────────────────────────────────────────┐
│                      后端服务层 (Backend)                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │  文档处理    │  │  知识库      │  │   AI服务     │       │
│  │   服务       │  │   服务       │  │    网关      │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└─────────────────────────────────────────────────────────────┘
                            ↕
┌─────────────────────────────────────────────────────────────┐
│                      数据存储层 (Storage)                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │  文件存储    │  │  向量数据库   │  │  元数据库    │       │
│  │  (MinIO)     │  │  (Milvus)    │  │  (SQLite)    │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└─────────────────────────────────────────────────────────────┘
                            ↕
┌─────────────────────────────────────────────────────────────┐
│                      AI服务层 (AI Services)                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │  OpenAI API  │  │ 国内大模型API │  │  本地模型    │       │
│  │              │  │ (文心/通义)   │  │  (Ollama)    │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
│  ┌──────────────┐  ┌──────────────┐                         │
│  │  Embedding   │  │  网络搜索    │                         │
│  │    服务      │  │    服务      │                         │
│  └──────────────┘  └──────────────┘                         │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 技术栈详细说明

#### 前端技术栈
```
框架：Vue 3 + TypeScript
UI组件库：Element Plus / Ant Design Vue
状态管理：Pinia
路由：Vue Router
HTTP客户端：Axios
实时通信：WebSocket (授课助手)
PPT集成：Office Online API / OnlyOffice
文档预览：PDF.js, docx-preview
```

#### 后端技术栈
```
语言：Python 3.10+
框架：FastAPI
异步任务：Celery + Redis
文档处理：
  - python-docx (Word文档)
  - PyPDF2 (PDF)
  - python-pptx (PPT)
  - Pillow (图片)
  - pytesseract (OCR)
向量数据库：Milvus / ChromaDB
文件存储：MinIO / 本地文件系统
数据库：SQLite / PostgreSQL
```

#### AI服务
```
LLM接口：
  - OpenAI API (GPT-4, GPT-3.5)
  - 百度文心一言 API
  - 阿里通义千问 API
  - Ollama (本地部署)

Embedding模型：
  - text-embedding-ada-002 (OpenAI)
  - m3e-base (本地中文模型)
  - bge-large-zh (本地中文模型)

网络搜索：
  - Serper API
  - Bing Search API
  - Google Custom Search API
```

---

## 三、核心模块设计

### 3.1 知识库管理模块

#### 3.1.1 功能设计
- 文档上传：支持拖拽上传、批量上传
- 文档解析：自动提取文本、图片、表格内容
- 文档预览：在线预览各类文档格式
- 文档管理：分类、标签、搜索、删除
- 版本控制：文档更新历史记录

#### 3.1.2 文档处理流程
```
上传文档 → 格式识别 → 内容提取 → 分块处理 → 向量化 → 存储
         ↓
      图片OCR → 文本提取 → 向量化 → 存储
```

#### 3.1.3 文档分块策略
```python
# 分块配置
CHUNK_CONFIG = {
    "max_chunk_size": 500,      # 最大块大小（字符）
    "overlap_size": 50,         # 重叠大小
    "separator": ["\n\n", "\n", "。", "；"],  # 分隔符优先级
    "respect_sentence": True,   # 尊重句子边界
}
```

### 3.2 AI备课助手模块

#### 3.2.1 功能设计
- 文档阅读器：分屏显示文档和AI对话窗口
- 智能问答：基于知识库的RAG问答
- 引用溯源：回答标注来源文档和位置
- 对话历史：保存和导出对话记录
- 快捷提问：预设常见问题模板

#### 3.2.2 RAG检索流程
```
用户提问 → 问题理解 → 向量检索 → 相关文档召回 → 重排序
         ↓
    知识库文档片段 (Top-K) → 上下文构建 → LLM生成回答 → 返回结果
```

#### 3.2.3 提示词模板
```
你是一位专业的教学备课助手。请基于以下知识库内容回答教师的问题。

知识库内容：
{context}

教师问题：{question}

要求：
1. 回答要准确、专业，优先使用知识库中的内容
2. 如果知识库中没有相关信息，请明确说明
3. 在回答末尾标注引用的文档来源
4. 回答要简洁明了，适合教学场景使用

回答：
```

### 3.3 授课AI助手模块

#### 3.3.1 功能设计
- 悬浮窗口：可拖拽、可调整大小的悬浮对话窗口
- 快捷唤起：全局快捷键唤起（如 Ctrl+Shift+A）
- PPT识别：自动识别当前播放的PPT内容
- 双轨回答：同时展示知识库答案和网络搜索结果
- 语音输入：支持语音转文字提问（可选）
- 历史记录：授课过程中的问答记录

#### 3.3.2 PPT集成方案
```
方案一：浏览器插件方式
- 开发Chrome/Edge扩展
- 注入脚本到Office Online页面
- 监听PPT播放状态
- 获取当前幻灯片内容

方案二：独立悬浮窗口
- Electron开发独立窗口应用
- 系统级悬浮窗（始终置顶）
- 通过剪贴板或OCR获取PPT内容
- 与Web后端通信

推荐方案二（更适合单用户场景）
```

#### 3.3.3 双轨并行回答流程
```
学生问题 → 并行处理
         ↓                ↓
    知识库检索        网络搜索
         ↓                ↓
    本地知识回答      网络信息回答
         ↓                ↓
         └────→ 结果整合 ←────┘
                   ↓
              展示给教师
```

---

## 四、数据库设计

### 4.1 数据库ER图

```
┌─────────────┐       ┌─────────────┐       ┌─────────────┐
│   User      │       │  Document   │       │   Chunk     │
├─────────────┤       ├─────────────┤       ├─────────────┤
│ id (PK)     │──┐    │ id (PK)     │──┐    │ id (PK)     │
│ username    │  │    │ title       │  │    │ document_id │
│ password    │  │    │ file_path   │  │    │ content     │
│ created_at  │  │    │ file_type   │  │    │ chunk_index │
│ updated_at  │  │    │ file_size   │  │    │ vector_id   │
└─────────────┘  │    │ category    │  │    │ created_at  │
                 │    │ tags        │  │    └─────────────┘
                 │    │ user_id(FK) │──┘           ↑
                 │    │ created_at  │              │
                 │    │ updated_at  │              │
                 │    └─────────────┘              │
                 │                                 │
                 │    ┌─────────────┐       ┌─────────────┐
                 │    │ Conversation│       │  Message    │
                 │    ├─────────────┤       ├─────────────┤
                 │    │ id (PK)     │──┐    │ id (PK)     │
                 │    │ title       │  │    │ conversation_id│
                 │    │ type        │  │    │ role        │
                 │    │ user_id(FK) │──┼────│ content     │
                 │    │ created_at  │  │    │ sources     │
                 │    │ updated_at  │  │    │ created_at  │
                 │    └─────────────┘  │    └─────────────┘
                 │                     │
                 └─────────────────────┘
```

### 4.2 数据表详细设计

#### 用户表 (users)
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 文档表 (documents)
```sql
CREATE TABLE documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(20) NOT NULL,  -- docx, pdf, pptx, txt, image
    file_size INTEGER,
    category VARCHAR(50),             -- 教案、课标、教材、其他
    tags TEXT,                        -- JSON数组存储标签
    user_id INTEGER NOT NULL,
    status VARCHAR(20) DEFAULT 'processing',  -- processing, ready, error
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

#### 文档分块表 (chunks)
```sql
CREATE TABLE chunks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    vector_id VARCHAR(100),           -- 向量数据库中的ID
    page_number INTEGER,              -- PDF/Word页码
    position_info TEXT,               -- JSON存储位置信息
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
);
```

#### 对话表 (conversations)
```sql
CREATE TABLE conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(255),
    type VARCHAR(20) NOT NULL,        -- preparation, teaching
    user_id INTEGER NOT NULL,
    document_id INTEGER,              -- 备课助手关联的文档
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (document_id) REFERENCES documents(id)
);
```

#### 消息表 (messages)
```sql
CREATE TABLE messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL,
    role VARCHAR(20) NOT NULL,        -- user, assistant
    content TEXT NOT NULL,
    sources TEXT,                     -- JSON数组存储引用来源
    search_results TEXT,              -- JSON存储网络搜索结果
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
);
```

#### AI配置表 (ai_configs)
```sql
CREATE TABLE ai_configs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    provider VARCHAR(50) NOT NULL,    -- openai, wenxin, qianwen, ollama
    model_name VARCHAR(100) NOT NULL,
    api_key VARCHAR(255),
    api_base VARCHAR(255),
    temperature REAL DEFAULT 0.7,
    max_tokens INTEGER DEFAULT 2000,
    is_active BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

---

## 五、API接口设计

### 5.1 知识库管理API

#### 上传文档
```
POST /api/documents/upload
Content-Type: multipart/form-data

Request:
- file: 文档文件
- category: 分类（可选）
- tags: 标签（可选，JSON数组）

Response:
{
    "code": 200,
    "message": "上传成功",
    "data": {
        "document_id": 123,
        "status": "processing"
    }
}
```

#### 获取文档列表
```
GET /api/documents?page=1&size=20&category=教案&keyword=数学

Response:
{
    "code": 200,
    "data": {
        "total": 50,
        "items": [
            {
                "id": 123,
                "title": "小学数学教案.docx",
                "file_type": "docx",
                "category": "教案",
                "tags": ["数学", "小学"],
                "status": "ready",
                "created_at": "2024-01-15 10:30:00"
            }
        ]
    }
}
```

#### 删除文档
```
DELETE /api/documents/{document_id}

Response:
{
    "code": 200,
    "message": "删除成功"
}
```

### 5.2 AI备课助手API

#### 创建对话
```
POST /api/conversations

Request:
{
    "document_id": 123,
    "type": "preparation"
}

Response:
{
    "code": 200,
    "data": {
        "conversation_id": 456
    }
}
```

#### 发送消息
```
POST /api/conversations/{conversation_id}/messages

Request:
{
    "content": "这个教案的核心教学目标是什么？"
}

Response:
{
    "code": 200,
    "data": {
        "message_id": 789,
        "role": "assistant",
        "content": "根据教案内容，核心教学目标是...",
        "sources": [
            {
                "document_id": 123,
                "document_title": "小学数学教案.docx",
                "chunk_id": 5,
                "content": "相关内容片段..."
            }
        ],
        "created_at": "2024-01-15 11:00:00"
    }
}
```

### 5.3 授课AI助手API

#### 快速问答（双轨并行）
```
POST /api/teaching/quick-ask

Request:
{
    "question": "为什么1+1=2？",
    "ppt_content": "当前PPT内容（可选）",
    "enable_web_search": true
}

Response:
{
    "code": 200,
    "data": {
        "knowledge_answer": {
            "content": "根据知识库中的内容...",
            "sources": [...]
        },
        "web_answer": {
            "content": "根据网络搜索结果...",
            "sources": [
                {
                    "title": "数学基础理论",
                    "url": "https://...",
                    "snippet": "..."
                }
            ]
        }
    }
}
```

---

## 六、向量数据库设计

### 6.1 Collection设计

```python
collection_schema = {
    "name": "knowledge_base",
    "description": "知识库向量存储",
    "fields": [
        {
            "name": "id",
            "dtype": "VARCHAR",
            "is_primary": True,
            "max_length": 100
        },
        {
            "name": "embedding",
            "dtype": "FLOAT_VECTOR",
            "dim": 768  # 根据embedding模型调整
        },
        {
            "name": "document_id",
            "dtype": "INT64"
        },
        {
            "name": "chunk_id",
            "dtype": "INT64"
        },
        {
            "name": "content",
            "dtype": "VARCHAR",
            "max_length": 2000
        }
    ],
    "index_params": {
        "metric_type": "COSINE",
        "index_type": "IVF_FLAT",
        "params": {"nlist": 1024}
    }
}
```

### 6.2 检索策略

```python
def hybrid_search(query: str, top_k: int = 5):
    # 向量检索
    vector_results = vector_db.search(
        collection_name="knowledge_base",
        query_vector=embed_query(query),
        limit=top_k * 2
    )
    
    # 关键词检索（可选）
    keyword_results = keyword_search(query, top_k * 2)
    
    # 融合排序
    merged_results = reciprocal_rank_fusion(
        vector_results, 
        keyword_results
    )
    
    return merged_results[:top_k]
```

---

## 七、部署架构

### 7.1 本地部署方案（推荐）

```
┌─────────────────────────────────────────┐
│           本地服务器 (localhost)          │
│  ┌────────────────────────────────────┐ │
│  │   Nginx (反向代理)                  │ │
│  │   - 前端静态文件服务                 │ │
│  │   - API代理                         │ │
│  └────────────────────────────────────┘ │
│  ┌────────────────────────────────────┐ │
│  │   FastAPI应用 (端口8000)            │ │
│  │   - 知识库服务                      │ │
│  │   - AI服务网关                      │ │
│  │   - WebSocket服务                   │ │
│  └────────────────────────────────────┘ │
│  ┌────────────────────────────────────┐ │
│  │   Celery Worker                    │ │
│  │   - 文档处理任务                    │ │
│  │   - 向量化任务                      │ │
│  └────────────────────────────────────┘ │
│  ┌────────────────────────────────────┐ │
│  │   Redis (消息队列/缓存)             │ │
│  └────────────────────────────────────┘ │
│  ┌────────────────────────────────────┐ │
│  │   Milvus (向量数据库)               │ │
│  └────────────────────────────────────┘ │
│  ┌────────────────────────────────────┐ │
│  │   SQLite (元数据库)                 │ │
│  └────────────────────────────────────┘ │
│  ┌────────────────────────────────────┐ │
│  │   文件存储 (本地文件系统)            │ │
│  └────────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

### 7.2 Docker Compose配置

```yaml
version: '3.8'

services:
  web:
    build: ./backend
    ports:
      - "8000:8000"
    volumes:
      - ./data/files:/app/files
      - ./data/db:/app/db
    environment:
      - DATABASE_URL=sqlite:///./db/app.db
      - REDIS_URL=redis://redis:6379
      - MILVUS_HOST=milvus
    depends_on:
      - redis
      - milvus

  celery:
    build: ./backend
    command: celery -A app.celery worker --loglevel=info
    volumes:
      - ./data/files:/app/files
    environment:
      - REDIS_URL=redis://redis:6379
      - MILVUS_HOST=milvus
    depends_on:
      - redis
      - milvus

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - ./data/redis:/data

  milvus:
    image: milvusdb/milvus:latest
    ports:
      - "19530:19530"
    volumes:
      - ./data/milvus:/var/lib/milvus

  frontend:
    build: ./frontend
    ports:
      - "80:80"
    depends_on:
      - web
```

---

## 八、安全设计

### 8.1 数据安全
- 文档加密存储（可选）
- API密钥加密存储
- 用户密码哈希存储（bcrypt）
- HTTPS传输加密

### 8.2 访问控制
- JWT身份认证
- API访问频率限制
- 文件上传大小限制
- 文件类型白名单验证

### 8.3 隐私保护
- 本地部署，数据不出本地
- 支持完全离线模式（使用本地模型）
- 对话历史本地存储
- 可配置数据保留策略

---

## 九、性能优化

### 9.1 文档处理优化
- 异步处理大文件
- 文档分块并行处理
- 向量化批处理
- 增量更新机制

### 9.2 检索优化
- 向量索引优化（IVF、HNSW）
- 查询缓存
- 分页加载
- 预加载热门文档

### 9.3 前端优化
- 文档懒加载
- 虚拟滚动
- WebSocket长连接
- 离线缓存

---

## 十、扩展性设计

### 10.1 AI模型扩展
- 统一的LLM接口抽象
- 配置化模型切换
- 支持自定义模型接入

### 10.2 功能扩展
- 插件化架构
- 支持第三方工具集成
- API开放接口

### 10.3 存储扩展
- 支持多种向量数据库
- 支持云存储（OSS、S3）
- 支持多种关系型数据库

---

## 十一、开发计划

### 11.1 第一阶段（核心功能）
- [ ] 用户认证系统
- [ ] 文档上传和解析
- [ ] 知识库管理
- [ ] 基础RAG问答
- [ ] AI备课助手

### 11.2 第二阶段（授课功能）
- [ ] 悬浮窗口应用
- [ ] PPT内容识别
- [ ] 网络搜索集成
- [ ] 双轨并行回答
- [ ] 授课历史记录

### 11.3 第三阶段（优化完善）
- [ ] 性能优化
- [ ] UI/UX优化
- [ ] 多模型支持
- [ ] 导出功能
- [ ] 数据备份恢复

---

## 十二、技术风险与应对

| 风险项 | 影响 | 应对措施 |
|--------|------|----------|
| 大文件处理慢 | 用户体验 | 异步处理+进度提示 |
| 向量检索精度低 | 回答质量 | 多路召回+重排序 |
| AI API调用失败 | 功能不可用 | 重试机制+降级方案 |
| PPT内容获取困难 | 授课功能受限 | 多种方案备选 |
| 本地模型性能不足 | 响应慢 | 支持云API切换 |

---

## 十三、总结

本架构设计充分考虑了教师备课和授课的实际需求，采用现代化的技术栈和成熟的AI技术，具备以下特点：

1. **易用性**：Web应用+悬浮窗口，操作简单直观
2. **灵活性**：支持多种AI模型，可本地可云端
3. **安全性**：本地部署，数据安全可控
4. **扩展性**：模块化设计，易于功能扩展
5. **高性能**：异步处理、向量检索、缓存优化

该系统将有效提升教师备课效率和授课质量，是教育信息化的重要工具。
